# Ayaanle Show - Simple Business Profile Website

Files included:
- index.html -- main site
- css/style.css -- styles
- contact.php -- basic contact form handler (sends email to jipo2410@gmail.com)
- README.md

How to use:
1. Upload the files to your web hosting. Place `index.html` in the site root and the `css` folder alongside it.
2. For the contact form to work, your hosting must support PHP and the `mail()` function, or you should configure SMTP.
3. Edit the files to update text, images, and contact details.

Contact:
- Phone: +252 638888431
- Email: jipo2410@gmail.com
